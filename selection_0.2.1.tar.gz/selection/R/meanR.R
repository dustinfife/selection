meanR <-
function(xbar, xbari, ni, n){
	meanR = (n*xbar-ni*xbari)/(n-ni)
	return(meanR)
	}
