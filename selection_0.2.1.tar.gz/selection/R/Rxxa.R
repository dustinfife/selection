Rxxa <-
function(ux, rxxi){
	rxxa = 1-ux^2*(1-rxxi)
	return(rxxa)
	}
